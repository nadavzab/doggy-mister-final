const config = {
    host: "localhost",
    user: "root",
    password: "",
    database: "",
};

module.exports = config;